from django.shortcuts import render, redirect, get_object_or_404, HttpResponseRedirect
from django.contrib.auth.decorators import login_required
from store.models.product import Product
from store.forms import ProductForm


# Create your views here.

def addandshow(request):
    if request.user.is_authenticated:
        if request.method == 'POST':
            form = ProductForm(request.POST)
            if form.is_valid():
                name = form.cleaned_data['name']
                price = form.cleaned_data['price']
                category = form.cleaned_data['category']
                description = form.cleaned_data['description']
                image = form.cleaned_data['image']
                reg = Product(name = name, price= price, category = category, 
                description = description, image = image )
                reg.save(commit=True)
                form = ProductForm()
        else:
            form = ProductForm()
        products = Product.objects.all()
        return render(request,'addandshow.html',{'form':form,'products':products}) 

    else:
        return HttpResponseRedirect('login')



def update_items(request, pk, template_name='edit_items.html'):
    items= get_object_or_404(Product, pk=pk)### select * from student where id=pk(parameterized id),pk means primary key
    form = ProductForm(request.POST or None, instance=items)
    if form.is_valid():
        form.save(commit=True)
        return redirect('addandshow')
    return render(request, template_name, {'form':form})


def delete_items(request,pk):
    if request.method == 'POST':
        pi = Product.objects.get(pk=pk)
        pi.delete()
        return redirect('addandshow')

