from django.shortcuts import render, redirect
from store.forms import CustomerSignUpForm, EmployeeSignUpForm


def signup_register(request):
      return render(request,'signup_register.html')




def customer_signup(request):
    if request.method == 'POST':
        form = CustomerSignUpForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('homepage')

    else:
        form = CustomerSignUpForm()
    return render(request,'customer_signup.html',{'form':form} )


def employee_signup(request):
    if request.method == 'POST':
        form = EmployeeSignUpForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('homepage')

    else:
        form = EmployeeSignUpForm()
    return render(request,'employee_signup.html',{'form':form} )