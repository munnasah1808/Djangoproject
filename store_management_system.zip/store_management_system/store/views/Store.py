from django.shortcuts import render, HttpResponseRedirect
from store.models.product import Product
from store.middlewares.auth import auth_middleware
#from django.contrib.auth.decorators import login_required



#@login_required(login_url='login')
def detailsview(request ):
    if request.user.is_authenticated:
        products = Product.objects.all()
        return render(request,'store.html',{'products':products,'name':request.user.username})
    else:
        return HttpResponseRedirect('login')


    
