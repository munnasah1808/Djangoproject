from django.contrib import admin
from django.urls import path
from .views.home import index
from .views.Store import detailsview
from .views.crud import  addandshow, update_items, delete_items
from .views.signup import signup_register, customer_signup, employee_signup
from .views.login import login_view, logout_view




urlpatterns = [
    path('', index, name='homepage'),
    path('signup', signup_register, name='signup'),
    path('store', detailsview , name='store'),
    path('customer_signup',customer_signup, name='customer_signup'),
    path('employee_signup',employee_signup, name='employee_signup'),
    path('login', login_view, name='login'),
    path('logout', logout_view , name='logout'),
    path('addandshow', addandshow,name="addandshow"),
    path('update/<int:pk>/', update_items, name="update_items"),
    path('delete/<int:pk>/', delete_items, name="delete_items"),
   
   
]
