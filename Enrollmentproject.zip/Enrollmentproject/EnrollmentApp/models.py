from django.db import models
from datetime import datetime
from django.utils import timezone
from django.core.validators import MinLengthValidator

# Create your models here.    
class Addstudent(models.Model):
	student_name = models.CharField(max_length=30, blank=True)
	father_name = models.CharField(max_length=30, blank=True)
	date_of_birth = models.DateField(blank= True,null=True)
	address = models.CharField(max_length=200, blank=True)
	city = models.CharField(max_length=100,blank=True)
	state = models.CharField(max_length=100,blank=True)
	pincode = models.CharField(max_length=6,blank=True)
	phone = models.CharField(max_length=12,blank=True)
	email  = models.EmailField(unique=True)
	Class = models.CharField(max_length=2,blank=True)
	marks = models.FloatField()
	date_enrolled = models.DateTimeField(default=timezone.now)



	@staticmethod
	def isExists(self):
		if Addstudent.objects.filter(email = self.email):
			return True
		return False
