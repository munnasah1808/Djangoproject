from django.urls import path
from EnrollmentApp import views
from . views import *
urlpatterns = [
    path('', views.Dashboard,name="home"),
    path('add_student/', views.addstudent, name="add_student"),
    path('ajax/student/update/',views.update_student_info, name='crud_ajax_update'),
    path('ajax/student/delete/',views.delete_student_info, name='crud_ajax_delete'), 
]
