from django.contrib import admin
from .models import *

# Register your models here.
@admin.register(Addstudent)
class AddstudentAdmin(admin.ModelAdmin):
    list_display = ['id','student_name','email','phone','Class','marks']

