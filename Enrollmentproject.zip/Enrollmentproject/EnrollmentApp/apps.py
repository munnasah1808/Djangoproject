from django.apps import AppConfig


class EnrollmentappConfig(AppConfig):
    name = 'EnrollmentApp'
