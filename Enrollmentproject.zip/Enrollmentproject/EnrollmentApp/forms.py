from django import forms
from .models import *


class AddStudentForm(forms.ModelForm):
	class Meta:
		model = Addstudent
		fields = '__all__'
