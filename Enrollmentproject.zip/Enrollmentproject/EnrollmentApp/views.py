from django.conf import settings
from django.shortcuts import render, redirect, HttpResponseRedirect 
from .models import *
from django.http import JsonResponse
# Create your views here.
def Dashboard(request):
	dataset = Addstudent.objects.all()
	return render(request, "EnrollmentApp/studentinfo.html",{'dataset':dataset})



def addstudent(request):
	if request.method == 'POST':
		print(request.POST)
		if request.POST.get('studentname') and request.POST.get('phone')and request.POST.get('email')and request.POST.get('class')and request.POST.get('marks'):
			savestudent=Addstudent()
			savestudent.student_name=request.POST.get('studentname')
			savestudent.email=request.POST.get('email')
			savestudent.phone=request.POST.get('phone')
			savestudent.Class=request.POST.get('class')
			savestudent.marks=request.POST.get('marks')
			savestudent.save()
			return render(request, "EnrollmentApp/addstudent.html")	
	else:
		return render(request, "EnrollmentApp/addstudent.html")

def update_student_info(request):
	id1 = request.GET.get('id', None)
	student_name1 = request.GET.get('student_name', None)
	email1 = request.GET.get('email', None)
	phone1 = request.GET.get('phone', None)
	Class1 = request.GET.get('Class', None)
	marks1 = request.GET.get('marks', None)
	obj = Addstudent.objects.get(id=id1)
	obj.student_name = student_name1
	obj.email = email1
	obj.phone = phone1
	obj.Class = Class1
	obj.marks = marks1
	obj.save()
	user = {'id':obj.id,'student_name':obj.student_name,'email':obj.email,
	'phone':obj.phone,'Class':obj.Class,'marks':obj.marks,}
	data = {
	'user': user
	}
	print(data)
	return JsonResponse(data)



def delete_student_info(request):
	id1 = request.GET.get('id', None)
	Addstudent.objects.get(id=id1).delete()
	data = {
	'deleted': True
	}
	return JsonResponse(data)



